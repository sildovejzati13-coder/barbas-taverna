BARBAS TAVERNA WEBSITE

Files:
- index.html
- style.css
- images/

Recommended image names:
- hero.jpg
- moussaka.jpg
- pastitsio.jpg
- stifado.jpg
- greek-salad.jpg

Upload your own images into the images folder using these names,
or change the filenames inside index.html/style.css.
